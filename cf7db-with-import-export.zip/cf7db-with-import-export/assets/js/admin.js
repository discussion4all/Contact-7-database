//Select form name then call
function import_cf7(){

	var url = jQuery('#base_url').val();
	var cf7_id = parseInt(jQuery('#import_cf7_id').val());
	if(!isNaN(cf7_id)){
		url += "&import_cf7_id="+cf7_id;
	}
	window.location = url;
}

// check match filed 

jQuery(document).ready(function() {
	jQuery('#import_sheet').on('click',function(){
		var count = 0;
		jQuery(".match-key").each(function() {
			if(jQuery(this).val()){
				count ++;
			}
		});
		if(count){
			if(document.getElementById('importFormList').value != ''){
				return true;
			}
			return false;
		}
		else{
			alert('Please enter match CSV column name.');
			return false;
		}
	});
});
