<?php

/* 
 Import file 
 */
//Check contact form class exist or not 
if(!is_plugin_active('contact-form-7/wp-contact-form-7.php')){
	?><div class="notice error is-dismissible">
		<p>Please activate Contact Form plugin first.</p>
	</div><?php
}
else if(defined('WPCF7_VERSION') && WPCF7_VERSION < '4.6'){
	?><div class="notice error is-dismissible">
		<p>Please update latest version for Contact Form plugin first.</p>
	</div><?php
}
else{
	
    add_submenu_page('cf7db-list.php', 'Import CSV', 'Import CSV', 'manage_options', 
            'cf7db-import',  'cf7db_import' );
     function cf7db_form_list()
    {
       //Get all existing contact form list	
	$url = '';
	$fid = '';
	//Get selected form Id value
	if(isset($_GET['import_cf7_id']) && !empty($_GET['import_cf7_id'])){
		
		$fid = intval($_GET['import_cf7_id']);
		$menu_url = menu_page_url('cf7db-import',false);
		$url = $menu_url.'&import_cf7_id='.$fid;
	}
        $args = array(
            'post_type'=> 'wpcf7_contact_form',
            'order'    => 'ASC',
            'posts_per_page' => -1,
        );

        $the_query = new WP_Query( $args );
        $form_list = '' ;
        while ( $the_query->have_posts() ) : $the_query->the_post();
            $form_post_id = get_the_id();
            $title = get_the_title();
            $selected = ($form_post_id == $fid )?'selected':'';
            $form_list .= !empty($form_post_id)?'<option value="'.$form_post_id.'" '.$selected.'>'.$title.'</option>':'';

        endwhile;
            $output = !empty($form_list)?' <table class="form-table inner-row wrap">
                                    <tr class="form-field form-required select-form">
                                            <th>Select Form name</th>
                                            <td>
                                                    <select name="import_cf7_id" id="import_cf7_id" onchange="import_cf7()">
                                                            <option value="">Select form name</option>
                                                            '.$form_list.'
                                                    </select>
                                            </td>	
                                    </tr>
                                </table>':'';

        return $output;
    }
    //Get all contact form list here
    function cf7db_get_the_form_list($fid = ''){

            //Get All form information
            $forms = WPCF7_ContactForm::find();
            $form = array();
            //fetch each form information

            foreach ($forms as $k => $v){
                    //Check if form id not empty then get specific form related information
                    if(!empty($fid)){
                            if($v->id() == $fid){
                                    $form[] = $v;
                                    return $form;
                            }
                    }
                    else{
                            $form[] = $v;
                    }
        }
            return $form;
    }
    function cf7db_import(){
	//Get selected form Id value
	if(isset($_GET['import_cf7_id']) && !empty($_GET['import_cf7_id'])){
		
            $fid = intval($_GET['import_cf7_id']);
            $menu_url = menu_page_url('cf7db-import',false);
            $url = $menu_url.'&import_cf7_id='.$fid;
	} 
        $msg = '';
	/************* Save CSV file related key names ******************/
        // Call When import CSV sheet.
	if(isset($_POST['submit']) && isset($_FILES['importFormList']) && !empty($_FILES['importFormList']['name']) && isset($_POST['wp_entry_nonce']) && isset($_POST['import_cf7_id']) && !empty($_POST['import_cf7_id']) && isset($_POST['form_match_key'])){
		require_once('import_cf7db_entry.php');
	}

	//Define nonce values here 
	$entry_nonce = wp_create_nonce('import-cf7-save-entry-nonce');
    ?>
        <div class="wrap">
            <div id="icon-users" class="icon32"></div>
            <h2><?php _e( 'Import File', 'cf7db' ); ?></h2>
        </div>
        <?php echo cf7db_form_list(); ?>
        <div class="tab-content">
            <div id="tab1" class="tab active">
                <form name="importEntryForm" action="<?php echo esc_url($url);?>" method="post" enctype="multipart/form-data">
                    <input type="hidden" name="base_url" id="base_url" value="<?php menu_page_url('cf7db-import');?>">
                    <table class="form-table abc"><?php
                        if(!empty($fid)){
                            //Get id related form details
                            $obj_form = cf7db_get_the_form_list(intval($fid));
                            //Get form related fields information
                            $arr_form_tag = $obj_form[0]->scan_form_tags();

                            $arr_option_type = array('checkbox','radio','select');
                            if(!empty($arr_form_tag)){
                                    ?><h3 class="advanced">Field Setting</h3>
                                    <tr><table class="form-table field-setting">
                                        <thead>
                                            <tr class="form-field form-required">
                                                <th>Field name</th>
                                                <th>Type</th>                                                  
                                                <th>Match CSV Column</th>
                                            </tr>
                                        </thead>	
                                        <tbody><?php
                                            foreach($arr_form_tag as $key => $arr_type){
                                                if($arr_type['basetype'] == 'submit' || $arr_type['basetype'] == 'recaptcha') continue;
                                                if(isset($arr_type['basetype']) && in_array($arr_type['basetype'],$arr_option_type)){
                                                    ?><tr class="form-field form-required">
                                                        <td><?php echo  esc_html($arr_type['name']); ?></td>
                                                        <td><?php echo  esc_html($arr_type['basetype']); ?></td>
                                                        <td><input class="match-key" type="text" name="form_match_key[<?php echo $arr_type['name'];?>]" value="<?php echo esc_html($arr_type['name']); ?>">
                                                        <!-- Define fields key related field type value -->
                                                        <input type="hidden" name="cf7db_field_type[<?php echo esc_html($arr_type['name']); ?>]" value="<?php echo esc_html($arr_type['basetype']); ?>">
                                                        </td>
                                                    </tr><?php
                                                }
                                                else{
                                                    ?><tr class="form-field form-required">
                                                        <td><?php echo esc_html($arr_type['name']); ?></td>
                                                        <td><?php echo esc_html($arr_type['basetype']); ?></td>
                                                        <!--<td></td>-->
                                                        <td><input class="match-key" type="text" name="form_match_key[<?php echo $arr_type['name'];?>]" value="<?php echo esc_html($arr_type['name']); ?>">
                                                        <!-- Define fields key related field type value -->
                                                        <input type="hidden" name="cf7db_field_type[<?php echo esc_html($arr_type['name']); ?>]" value="<?php echo esc_html($arr_type['basetype']); ?>">
                                                        </td>
                                                    </tr><?php
                                                }
                                            }
                                            ?>
                                        </tbody>
                                    </table></tr><?php	
                            }
                            ?><table class="form-table">
                                    <tr>
                                            <th><!--<h3 class="advanced">Import CSV</h3>--></th>
                                            <td>	
                                            </td>	
                                    </tr>
                                    <tr class="form-field form-required">
                                        <th><label for="importFormList">Upload CSV :</label></th>
                                        <td>
                                                <input type="file" name="importFormList" id="importFormList" accept=".csv" onchange="checkfile(this);"/>
                                        </td>
                                    </tr>
                                    <tr class="form-field form-required">
                                        <th></th>
                                        <td>
                                                <input type="submit" id="import_sheet" name="submit" value="Import Data" class="button button-primary"/>
                                        </td>
                                    </tr>
                            </table>
                            <input type="hidden" name="wp_entry_nonce" value="<?php echo $entry_nonce; ?>" />
                            <input type="hidden" name="import_cf7_id" value="<?php echo $fid; ?>" /><?php
                    }	
                ?></table><!--Close main Table-->
                </form>
            </div>
    </div>
    <?php

    }
}