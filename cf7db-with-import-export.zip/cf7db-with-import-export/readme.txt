=== Contact Form 7 Database Addon - CF7DB ===
Tags: cf7, contact form 7, contact form 7 db, contact form db, contact form seven, contact form storage, export contact form, save contact form, wpcf7
Requires at least: 4.8
Tested up to: 5.4
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Requires PHP: 5.6

Save and manage Contact Form 7 messages. Never lose important data. It is lightweight contact form 7 database plugin.


== Description ==

The "CF7DB" plugin saves contact form 7 submissions to your WordPress database. Export the data to a CSV file.
By simply installing the plugin, it will automatically begin to capture form submissions from contact form 7.

= Features of CFDB7 =

* No configuration is needed
* Save Contact Form 7 form submitted data to the database.
* Single database table for all contact form 7 forms
* Easy to use and lightweight plugin
* Developer friendly & easy to customize
* Display all created contact form 7 form list.
* Export CF7 DB (CF7 Database) data in CSV file
* Import CF7 DB (CF7 Database) data in CSV file


== Installation ==

1. Download and extract plugin files to a wp-content/plugin directory.
2. Activate the plugin through the WordPress admin interface.
3. Done !


== Screenshots ==


== Changelog ==

= 1.0

1.import function
2.export function
3.first plugin 














